# CRUD-Sederhana-JAVA-dengan-Database

1.Import database 'db_barang.sql' menggunakan MySQL pada localhost/phpmyadmin di Browser Anda.Pastikan MySQL & Apache berjalan.

2.Buka Aplikasi Neteans.

3.Pilih 'Open Project'.

4.Pilih Direktori dimana aplikasi ini disimpan.

5.Klik tombol Shift+F6 atau Debug & Run Frm_Login.Pastikan Form awal yang terbuka adalah Frm_Login*

6.Aplikasi siap digunakan.


* = username admin default adalah admin dengan password admin123.Anda bisa mengganti atau membuat akun baru di phpmyadmin 
